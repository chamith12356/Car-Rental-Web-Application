<?php 

    require('../admin/inc/db_config.php');
    require('../admin/inc/essentials.php');
    date_default_timezone_set("Asia/colombo");

    session_start( );

    if (isset($_GET['fetch_cars'])) 
    {
        //check avilibility data decode
        $chk_avail= json_decode($_GET['chk_avail'],true);

        // input purchase and return date filter validation
        if ($chk_avail['checkin']!='' && $chk_avail['checkout']!='')
        {
            $today_date = new DateTime(date('Y-m-d'));
            $checkin_date = new DateTime($chk_avail['checkin']);
            $checkout_date = new DateTime($chk_avail['checkout']);

            if($checkin_date == $checkout_date){
                echo "<h3 class='text-center text-danger'>Purchased Date and Returned Date can't Equal</h3>";
                exit;
            }else if($checkout_date < $checkin_date){
                echo "<h3 class='text-center text-danger'>Returned Date Invalid </h3>";
                exit;
            }else if($checkin_date < $today_date){
                echo "<h3 class='text-center text-danger'>Purchased Date Invalid</h3>";
                exit;
            }

        }

        //guest data decode
        $guests = json_decode($_GET['guests'],true);
        $type =($guests['type']!='')? $guests['type']:0;

        //facility data decode
        $facility_list = json_decode($_GET['facility_list'],true);

        // count no.of cars and output variable to store cars 
        $count_cars = 0;
        $output = "";

        //fatching settings table to check website is shotdown or not
        $settings_q = "SELECT * FROM `settings` WHERE `sr_no`=1";
        $values = [];
        $settings_r = mysqli_fetch_assoc(mysqli_query($con, $settings_q));
        
        // Assuming $type is a variable containing the Type value
        $car_res = select("SELECT * FROM `car` WHERE `type`='$type' AND `status`=? AND `removed`=?", [ 1, 0], 'ii');
        

        while ($car_data = mysqli_fetch_assoc($car_res))
        {
          
          $fec_count=0;

          $fec_q = mysqli_query($con, "SELECT f.name, f.id FROM `facilities` f INNER JOIN `car_facilities` rfea ON f.id = rfea.facilities_id WHERE rfea.car_id = '{$car_data['id']}'");
          $facilities_data = "";
          while ($fec_row = mysqli_fetch_assoc($fec_q)) 
          {
            
            if( in_array($fec_row['id'],$facility_list['facilities'])){
                    $fec_count++;
            }

            $facilities_data .= " <span class='badge rounded-pill bg-light text-dark text-wrap '> $fec_row[name] </span>";
          }

          if(count($facility_list['facilities'])!=$fec_count){
            continue;
          }
          
          //features of car
          $fea_q = mysqli_query($con, "SELECT f.name FROM `features` f INNER JOIN `car_features` rfea ON f.id = rfea.features_id WHERE rfea.car_id = '{$car_data['id']}'");
          $features_data = "";
          while ($fea_row = mysqli_fetch_assoc($fea_q)) {
            $features_data .= " <span class='badge rounded-pill bg-light text-dark text-wrap '> $fea_row[name] </span>";
          }

         

          $car_thumb = CARS_IMG_PATH . "thumbnail.jpg";
          $thumb_q = mysqli_query($con, "SELECT * FROM `car_images` WHERE `car_id`='{$car_data['id']}' AND `thumb`='1'");

          if (mysqli_num_rows($thumb_q) > 0) {
            $thumb_res = mysqli_fetch_assoc($thumb_q);
            $car_thumb = CARS_IMG_PATH . $thumb_res['image'];
          }

          $output.= "
           <div class='card mb-4 border-0 shadow'>
               <div class='row g-0 p-3 align-items-center'>
                   <div class='col-md-5 mb-lg-0 mb-md-0 mb-3'>
                       <img src='$car_thumb' class='img-fluid rounded'>
                   </div>
       
                   <div class='col-md-5 px-lg-3 px-md-3 px-0'>
                       <h5 class='mb-3'>{$car_data['name']}</h5>
       
                       <div class='fearures mb-3'>
                           <h6 class='mb-1'> Car Features</h6>
                           $features_data
                       </div>
       
                       <div class='Services mb-3'>
                           <h6 class='mb-1'> Car Services</h6>
                           $facilities_data
                       </div>
                   </div>
       
                   <div class='col-md-2 mt-lg-0 mt-md-0 mt-4 text-center'>
                       <h6 class='mb-4'>Rs. {$car_data['budegt']}</h6>
                       <a href='car_details.php?id={$car_data['id']}' class='btn btn-sm w-100 text-white btn-outline-dark custom-bg shadow-none mb-2'>Purchase Car</a>
                       <a href='car_details.php?id={$car_data['id']}' class='btn btn-sm w-100 btn-outline-dark shadow-none'>More Details</a>
                   </div>
               </div>
           </div>
        ";
          $count_cars++;
    
        }

        if ($count_cars > 0) {
            echo $output;
        }
        else {
            echo "<h3 class='text-center text-danger'>No cars for available shows</h3>";
        }
    
    }

?>