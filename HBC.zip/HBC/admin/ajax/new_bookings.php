<?php
  require('../inc/db_config.php');
  require('../inc/essentials.php');
  adminLogin();

  if (isset($_POST['get_bookings'])) 
  {
    $query = "SELECT bo.*, bd.* FROM `rental_order` bo
    INNER JOIN `rental_details` bd ON bo.booking_id=bd.booking_id
    WHERE bo.rental_status = 'booked' AND bo.arrival = 0 ORDER BY bo.booking_id ASC";


    $res = mysqli_query($con, $query);
    $i=1;
    $table_data = "";

    while ($data = mysqli_fetch_array($res))
    {
        $date = date("d-m-y", strtotime($data["datentime"]));
        $rental_date = date("d-m-y", strtotime($data["rental_date"]));
        $return_date = date("d-m-y", strtotime($data["return_date"]));

      $table_data .="
        <tr>
          <td>$i</td>
          <td>
            <span class='badge bg-primary'>
              Order ID:$data[order_id]
            </span>
            <br>
            <b>Name:</b>$data[user_name]
            <br>
            <b>Phone No:</b>$data[phonenum]
          </td>
          <td>
            <b>Car:</b>$data[car_name]
            <br>
            <b>Price:</b>Rs.$data[rentalprice]
          </td>
          <td>
            <b>Rental-Date:</b>$rental_date
            <br>
            <b>Return-Date</b>$return_date
            <br>
            <b>Paid:</b>Rs.$data[trans_amount]
            <br>
            <b>Date:</b>$date	
          </td>
          <td>
            <button type='button' onclick='assign_car($data[booking_id])' class='btn text-white btn-sm fw-bold custom-bg shadow-none' data-bs-toggle='modal' data-bs-target='#assign-car'>
            <i class='bi bi-check2-square'></i>Assign Car</button>
            <br>
            <button type='button' onclick='cancel_booking($data[booking_id])' class='mt-2 btn btn-outline-danger btn-sm fw-bold shadow-none'>
            <i class='bi bi-trash'></i>Cancel Booking</button>
          </td>
        </tr>    
      ";

    $i++;
    }

    echo $table_data;
  }

  if (isset($_POST['assign-car']))
  {

    $frm_data = filteration($_POST);
  
    $query = "UPDATE `rental_order` bo INNER JOIN `rental_details` bd 
    ON bo.booking_id = bd.booking_id 
    SET bo.arrival = ?, bd.car_no = ? 
    WHERE bo.booking_id = ?";
  
    $values = [1, $frm_data['car_no'], $frm_data['booking_id']];
  
    $res = update($query, $values, 'isi'); // it will update 2 rows and it will return 2
  
    echo ($res == 2) ? 1 : 0;
  
  }  

  if (isset($_POST['cancel_booking']))
  {

    $frm_data = filteration($_POST);
  
    $query = "UPDATE `rental_order` SET 'rental_status'=?, 'refund'=? WHERE 'booking_id'=?";   
    $values = ['cancelled',0, $frm_data['booking_id']];  
    $res = update($query, $values,'sii');

    echo $res;  
  }  


?>
