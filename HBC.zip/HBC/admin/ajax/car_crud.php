<?php
require('../inc/db_config.php');
require('../inc/essentials.php');

if (isset($_POST['add_car'])) {
  $features = filteration(json_decode($_POST['features']));
  $facilities = filteration(json_decode($_POST['facilities']));
  echo 'PHP code is executed.' . implode(', ', $facilities) . ', ' . implode(', ', $features);


  $flag = 0;
  $frm_data = filteration($_POST);


  $q1 = "INSERT INTO `car`(`name`, `type`, `budegt`, `description`) VALUES (?,?,?,?)"; // Removed `person` column as it's not provided in the form.
  $values = [$frm_data['name'], $frm_data['type'], $frm_data['budegt'], $frm_data['desc']];

  if (insert($q1, $values, 'ssss')) {
    $flag = 1;
    alert('success', 'Add!');
    
  }


  $car_id = mysqli_insert_id($con);

  // ChatGpt-------------------------------------------------------------------------

if (!empty($facilities)) {
  $q2 = "INSERT INTO `car_facilities`(`car_id`, `facilities_id`) VALUES ";
  $q2 .= implode(', ', array_fill(0, count($facilities), "($car_id, ?)"));
  $stmt = mysqli_prepare($con, $q2);

  if ($stmt) {
      $types = str_repeat('i', count($facilities));
      mysqli_stmt_bind_param($stmt, $types, ...$facilities);

      // Execute the prepared statement
      mysqli_stmt_execute($stmt);

      // Close the prepared statement
      mysqli_stmt_close($stmt);
  } else {
      $flag = 0;
      die('Query cannot be prepared-insert');
  }
}

// Insert data into the car_features table
if (!empty($features)) {
  $q3 = "INSERT INTO `car_features`(`features_id`, `car_id`) VALUES ";
  $q3 .= implode(', ', array_fill(0, count($features), "(?, $car_id)"));
  $stmt = mysqli_prepare($con, $q3);

  if ($stmt) {
      $types = str_repeat('i', count($features));
      mysqli_stmt_bind_param($stmt, $types, ...$features);

      // Execute the prepared statement
      mysqli_stmt_execute($stmt);

      // Close the prepared statement
      mysqli_stmt_close($stmt);
  } else {
      $flag = 0;
      die('Query cannot be prepared-insert');
  }
}

mysqli_close($con);
// ------------------------------------------------------------------------------
}

if (isset($_POST['get_all_cars'])) {
  $res = select("SELECT * FROM `car` WHERE 'removed'=?",[0],'i');
  $i = 1;
  $data = "";

  while ($row = mysqli_fetch_assoc($res)) {

    if ($row['status'] == 1) {
      $status = "<button onclick='toggle_status($row[id],0)' class='btn btn-dark shadow-none'>active</button>";
    } else {
      $status = "<button onclick='toggle_status($row[id],1)' class='btn btn-warning shadow-none'>in active</button>";
    }

    $data .= "
  <tr class='align-middle'>
  <td>$i</td>


  <td>$row[name]</td>
  <td>$row[type]</td>
  <td>$row[budegt]</td>
  <td>$row[description]</td>
  <td>$status</td>
  <td>   
  <button type='button' onclick='edit_detailes($row[id])' class='btn btn-dark shadow-none btn-sm' data-bs-toggle='modal' data-bs-target='#edit-car-s'>
  <i class='bi bi-pencil-square'></i> 
  </button>
  <button type='button' onclick=\"car_images($row[id],'$row[name]')\" class='btn btn-info shadow-none btn-sm' data-bs-toggle='modal' data-bs-target='#car-images'>
  <i class='bi bi-images'></i> 
  </button>
  <button type='button' onclick='remove_car($row[id])' class='btn btn-danger shadow-none btn-sm'>
  <i class='bi bi-trash'></i> 
  </button>
  </td>
  </tr> 
  ";
    $i++;
  }
  echo $data;
}

if (isset($_POST['get_car'])) {

  $frm_data = filteration($_POST);
  $res1 = select("SELECT * FROM `car` WHERE `id`=?", [$frm_data['get_car']], 'i');
  $res2 = select("SELECT * FROM `car_features` WHERE `car_id`=?", [$frm_data['get_car']], 'i');
  $res3 = select("SELECT * FROM `car_facilities` WHERE `car_id`=?", [$frm_data['get_car']], 'i');

  $cardata = mysqli_fetch_assoc($res1);

  $features = [];
  $facilities = [];
  if (mysqli_num_rows($res2) > 0) {
    while ($row = mysqli_fetch_assoc($res2)) {
      array_push($features, $row['features_id']);
    }
  }
  if (mysqli_num_rows($res3) > 0) {
    while ($row = mysqli_fetch_assoc($res3)) {
      array_push($facilities, $row['facilities_id']);
    }
  }

  $data = ["cardata" => $cardata, "features" => $features, "facilities" => $facilities];
  $data = json_encode($data);
  echo $data;
}

if (isset($_POST['edit_car'])) {
  $features = filteration(json_decode($_POST['features']));
  $facilities = filteration(json_decode($_POST['facilities']));

  $flag = 0;
  $frm_data = filteration($_POST);


  $q = "UPDATE `car` SET `name`=?, `type`=?, `budegt`=?,  `description`=? WHERE `id`=?";
  $values = [$frm_data['name'], $frm_data['type'], $frm_data['budegt'], $frm_data['desc'], $frm_data['car_id']];

  if (update($q, $values, 'ssssi')) {
    $flag = 1;
  }

  // Delete existing features and facilities
  $del_features = delete("DELETE FROM `car_features` WHERE `car_id`=?", [$frm_data['car_id']], 'i');
  $del_facilities = delete("DELETE FROM `car_facilities` WHERE `car_id`=?", [$frm_data['car_id']], 'i');

  // Check if deletions were successful
  if ($del_features && $del_facilities) {
    $flag = 1;
  }

  // Insert new features
  $q2 = "INSERT INTO `car_facilities`(`car_id`, `facilities_id`) VALUES (?,?)";
  if ($stmt = mysqli_prepare($con, $q2)) {
    foreach ($facilities as $f) {
      mysqli_stmt_bind_param($stmt, 'ii', $frm_data['car_id'], $f);
      mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);
  } else {
    $flag = 0;
  }

  // Insert new facilities
  $q3 = "INSERT INTO `car_features`(`car_id`,`features_id`) VALUES (?,?)";
  if ($stmt = mysqli_prepare($con, $q3)) {
    foreach ($features as $f) {
      mysqli_stmt_bind_param($stmt, 'ii', $frm_data['car_id'], $f);
      mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);
  } else {
    $flag = 0;
  }

  if ($flag) {
    echo 1;
  } else {
    echo 0;
  }
}

if (isset($_POST['toggle_status'])) {
  $frm_data = filteration($_POST);
  $q = "UPDATE `car` SET `status`=? WHERE `id`=?";
  $v = [$frm_data['value'], $frm_data['toggle_status']];
  if (update($q, $v, 'ii')) {
    echo 1;
  } else {
    echo 0;
  }
}

if (isset($_POST['add_image'])) { //database dana hriya image tika

  $frm_data = filteration($_POST);
  $img_r = uploadImage($_FILES['image'], CARS_FOLDER);

  if ($img_r == 'inv_img') {
    echo $img_r;
  }
  else if ($img_r == 'inv_size') {
    echo $img_r;
  }
  else if ($img_r == 'upd_failed') {
    echo $img_r;
  }
  else {
    $q = "INSERT INTO `car_images`(`car_id`, `image`) VALUES (?,?)";
    $values = [$frm_data['car_id'], $img_r];
    $res = insert($q, $values, 'is');
    echo $res;
  }
}

if (isset($_POST['get_car_images'])) {

  $frm_data = filteration($_POST);
  $res = select("SELECT * FROM `car_images` WHERE `car_id`=?", [$frm_data['get_car_images']], 'i');

  $path = CARS_IMG_PATH;

  while($row = mysqli_fetch_assoc($res))
  {
    if($row['thumb'] == 1)
    {
      $thumb_btn = "<i class='bi bi-check-lg text-light bg-success px-2 py-1 rounded fs-5'></i>";
    }
    else
    {
      $thumb_btn = "<button onclick='thumb_image({$row['sr_no']}, {$row['car_id']})' class='btn btn-secondary shadow-none'>
        <i class='bi bi-check-lg'></i>
        </button>";
    }
    echo <<<data
      <tr class='align-middle'>
        <td><img src='$path{$row['image']}' class='img-fluid'></td>
        <td>$thumb_btn</td>
        <td>
          <button onclick='rem_image({$row['sr_no']}, {$row['car_id']})' class='btn btn-danger shadow-none'>
            <i class='bi bi-trash'></i>
          </button>
        </td>
      </tr>
data; 
  }
}


  if (isset($_POST['rem_image'])) 
  {
      $frm_data = filteration($_POST);

      $values = [$frm_data['image_id'],$frm_data['car_id']];

      $per_q = "SELECT * FROM `car_images` WHERE `sr_no`=? AND `car_id`=?";
      $res = select($per_q, $values, 'ii');
      $img = mysqli_fetch_assoc($res);

      if (deleteImage($img['image'],CARS_FOLDER)) {
        $q = "DELETE FROM `car_images` WHERE `sr_no`=? AND 'car_id'=?";
        $res = delete($q, $values, 'ii');
        echo $res;
      } 
      else {
      echo 0;
      }
  }

  
  if (isset($_POST['thumb_image'])) 
  {
      $frm_data = filteration($_POST);
  
      // Reset 'thumb' to 0 for all images of the same car
      $pre_q = "UPDATE `car_images` SET `thumb` = 0 WHERE `car_id` = ?";
      $pre_v = [$frm_data['car_id']];
      $pre_res = update($pre_q, $pre_v, 'i');
  
      // Set 'thumb' to 1 for the selected image of the same car
      $q = "UPDATE `car_images` SET `thumb` = 1 WHERE `sr_no` = ? AND `car_id` = ?";
      $v = [$frm_data['image_id'], $frm_data['car_id']];
      $res = update($q, $v, 'ii');
  
      echo $res;
  }
  
  if (isset($_POST['remove_car'])) 
{
    $frm_data = filteration($_POST);

    $res1 = select("SELECT * FROM `car_images` WHERE `car_id`=?", [$frm_data['car_id']], 'i');

    while ($row = mysqli_fetch_assoc($res1)) {
        deleteImage($row['image'], CARS_FOLDER);
    }

    $res2 = delete("DELETE FROM `car_images` WHERE `car_id`=?", [$frm_data['car_id']], 'i');
    $res3 = delete("DELETE FROM `car_features` WHERE `car_id`=?", [$frm_data['car_id']], 'i');
    $res4 = delete("DELETE FROM `car_facilities` WHERE `car_id`=?", [$frm_data['car_id']], 'i');
    $res5 = update("UPDATE `car` SET `removed`=? WHERE `id`=?", [1, $frm_data['car_id']], 'ii');

    if ($res2 || $res3 || $res4 || $res5) {
        echo 1;
    } else {
        echo 0;
    }
}


?>
