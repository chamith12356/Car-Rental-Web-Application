<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel-New Bookings</title>
  <?php require('inc/links.php'); ?>


</head>

<body class="bg-light">
  <?php require('inc/header.php'); ?>


  <div class="container-fluid " id="main-content">
    <div class="row">
      <div class="col-lg-10 ms-auto p-4 overflow-hidden ">
        <h3 class="mb-4">New Bookings</h3>
        <div class="table-responsive">
          <table class="table table-hover border">
            <thead>
              <tr class="bg-dark text-light">
                <th scope="col">#</th>
                <th scope="col">User Details</th>
                <th scope="col">Car Details</th>
                <th scope="col">Booking Details</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody id="table-data">
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

<!--ASSIGN CAR NUMBER MODEL -->
  <div class="modal fade" id="assign-car" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <form id="assign_car_form">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="staticBackdropLabel">Assign Car</h5>

                </div>
                <div class="modal-body">
                  <div class=" mb- 3">
                    <label for="name" class="form-label fw-bold">Car No</label>
                    <input type="text" name="car_no" class="form-control shadow-none" required>
                  </div>
                  <span class ="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                    Note: Assign Car Number only when user has been arrived!
                  </span>
                  <input type="hidden" name="booking_id">
                </div>
                <div class="modal-footer">
                  <button type="reset" class="btn btn-success" data-bs-dismiss="modal">CANCEL</button>
                  <button type="submit" class="btn bg-dark text-white shadow-none">ASSIGN</button>
                </div>
              </div>
            </form>
          </div>
        </div>


  <?php require('inc/scripts.php'); ?>

  <script src ="scripts/new_bookings.js"></script>

</body>
</html>