<?php

require('inc/essentials.php');

SESSION_START();
SESSION_DESTROY();
redirect('index.php')

?>