<?php

//front end img path

define('SITE_URL', 'http://127.0.0.1/HBC/');
define('ABOUT_IMG_PATH', SITE_URL . 'images/aboutus/');
define('CAROUSEL_IMG_PATH', SITE_URL . 'images/carousel/');
define('FEATURES_IMG_PATH', SITE_URL . 'images/features/');
define('CARS_IMG_PATH', SITE_URL . 'images/cars/');
define('USERS_IMG_PATH', SITE_URL . 'images/users/');


//back end image path
define('UPLOAD_IMAGE_PATH', $_SERVER['DOCUMENT_ROOT'] . '/HBC/images/');
define('ABOUT_FOLDER', 'aboutus/');
define('CAROUSEL_FOLDER', 'carousel/');
define('FEATURES_FOLDER', 'features/');
define('CARS_FOLDER', 'cars/');
define('USERS_FOLDER', 'users/');

// Send Grid API KEY - Meka aiyn karrana epa

define('SENDGRID_API_KEY',"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");
define('SENDGRID_EMAIL',"ushanloshitha@gmail.com");
define('SENDGRID_NAME',"UBC RENT A CAR");

function adminLogin()
{
  session_start();
  if (!(isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)) {

    echo "<script>
    window.location.href='index.php';
    </script>";
    exit;
  }
}
function redirect($url)
{
  echo "<script>
   window.location.href='$url';
   </script>";
  exit;
}

function alert($type, $msg)
{
  $bs_class = ($type == "success") ? "alert-success" : "alert-danger";

  echo <<<alert
    <div class="alert $bs_class alert-dismissible fade show custom-alert" role="alert">
        <strong class="me-3">$msg</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
alert;
}
function uploadImage($image, $folder)
{
  $valid_mime = ['image/jpeg', 'image/png', 'image/webp'];
  $img_mime = $image['type'];
  if (!in_array($img_mime, $valid_mime)) {
    return 'inv_img';
  } elseif (($image['size'] / (1024 * 1024)) > 3) {
    return 'inv_size';
  } else {
    $ext = pathinfo($image['name'], PATHINFO_EXTENSION);
    $rname = 'IMG_' . random_int(11111, 99999) . ".$ext";
    $img_path = UPLOAD_IMAGE_PATH . $folder . $rname; // Make sure UPLOAD_IMAGE_PATH is defined
    if (move_uploaded_file($image['tmp_name'], $img_path)) {
      return $rname;
    } else {
      return 'upd_failed';
    }
  }
}

function deleteImage($image, $folder)
{
  if (unlink(UPLOAD_IMAGE_PATH . $folder . $image)) {
    return true;
  } else {
    return false;
  }
}
// function deleteImage($image, $folder)
// {
//   return unlink(UPLOAD_IMAGE_PATH . $folder . $image);
// }
// function deleteImage($image, $folder)
// {
//   $filePath = UPLOAD_IMAGE_PATH . $folder . $image;
//   if (file_exists($filePath) && unlink($filePath)) {
//     return true;
//   } else {
//     return false;
//   }
// }

function uploadSVGImage($image, $folder)
{
  $valid_mime = ['image/svg+xml'];
  $img_mime = $image['type'];
  if (!in_array($img_mime, $valid_mime)) {
    return 'inv_img';
  } elseif (($image['size'] / (1024 * 1024)) > 3) {
    return 'inv_size';
  } else {
    $ext = pathinfo($image['name'], PATHINFO_EXTENSION);
    $rname = 'IMG_' . random_int(11111, 99999) . ".$ext";
    $img_path = UPLOAD_IMAGE_PATH . $folder . $rname; // Make sure UPLOAD_IMAGE_PATH is defined
    if (move_uploaded_file($image['tmp_name'], $img_path)) {
      return $rname;
    } else {
      return 'upd_failed';
    }
  }
}

function uploadUserImage($image){
  $valid_mime = ['image/jpeg', 'image/png', 'image/webp'];
  $img_mime = $image['type'];

  if (!in_array($img_mime, $valid_mime)) {
      return 'inv_img';
  } else {
      $ext = pathinfo($image['name'], PATHINFO_EXTENSION);
      $rname = 'IMG_' . random_int(11111, 99999) . ".jpeg";

      $img_path = UPLOAD_IMAGE_PATH.USERS_FOLDER.$rname; // Make sure UPLOAD_IMAGE_PATH is defined

      // Check if GD extension is enabled
      if (!extension_loaded('gd')) {
          return 'gd_extension_not_enabled';
      }

      // Attempt to create image resource based on file type
      switch ($ext) {
          case 'png':
          case 'PNG':
              if (!function_exists('imagecreatefrompng')) {
                  return 'gd_function_not_available';
              }
              $img = imagecreatefrompng($image['tmp_name']);
              break;
          case 'webp':
          case 'WEBP':
              if (!function_exists('imagecreatefromwebp')) {
                  return 'gd_function_not_available';
              }
              $img = imagecreatefromwebp($image['tmp_name']);
              break;
          default:
              if (!function_exists('imagecreatefromjpeg')) {
                  return 'gd_function_not_available';
              }
              $img = imagecreatefromjpeg($image['tmp_name']);
              break;
      }

      // Check if image resource creation was successful
      if ($img !== false) {
          // Save the image
          if (imagejpeg($img, $img_path, 75)) {
              // Free up memory
              imagedestroy($img);
              return $rname;
          } else {
              // Free up memory
              imagedestroy($img);
              return 'upd_failed';
          }
      } else {
          return 'img_create_failed';
      }
  }
}



?>
