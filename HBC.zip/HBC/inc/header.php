<nav id="nav-bar" class="navbar navbar-expand-lg navbar-light bg-white px - lg - 3 py - lg - 2 shadow - sm sticky - top">
  <div class="container-fluid">

  

    <div class="d-flex align-items-center">
      <img src="images/Header_photo/jeep.gif" width="60px" height="60px" style="margin-right: 10px;">
      <a class="navbar-brand me-5 fw-bold fs-3 h-font align-middle" href="index.php" style="font-family: 'Impact', sans-serif;"><?php echo $settings_r['site_title']?></a>
    </div>

    <button class="navbar-toggler shadow - none " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link me-2" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-2" href="Cars.php">Vehicle Fleet</a>
        </li>

        <li class="nav-item">
          <a class="nav-link me-2" href="services.php">Rental Packages</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-2" href="contact.php">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-2" href="AboutUs.php">About Us</a>
        </li>

        <li class="nav-item">
          <a class="nav-link me-2" href="FAQ.php">FAQS</a>
        </li>

        
        


         
    </div>

    <div class="d-flex align-items-center">
  <a href="login.html" class="btn btn-outline-dark me-4">Login</a>
  <a href="register.html" class="btn btn-dark">Register</a>
</div>



</div>








</nav>


