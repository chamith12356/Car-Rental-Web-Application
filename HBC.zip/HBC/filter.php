<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Data</title>
    <?php require('inc/links.php'); ?>

</head>
<body>

<div class="container">
    <form method="post">
        <input type="text" placeholder="search data" name="search">
        <button class="btn btn-dark" name="submit">Search</button>
    </form>
</div>

</body>
</html>